#pragma once
struct TreeNode
{
	int item;
	TreeNode* Lchild;
	TreeNode* Rchild;

};

class BST
{
public:
	BST();
	bool add(int i);
	void inorder();
	//TreeNode* root;
	int max();

//
private:
	TreeNode* root;

	void inorder(TreeNode*);


};