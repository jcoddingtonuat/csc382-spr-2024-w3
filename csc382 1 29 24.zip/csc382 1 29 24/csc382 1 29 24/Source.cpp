



#include "BST.h"
#include <iostream>
#include <string>
using namespace std;
int main()
{


	BST bst;
	int random;

	for (int i = 0; i < 100; i++)
	{
		random = 1 + (rand() % 100);
		cout << "Inserting " << random << endl;
		bst.add(random);
	}



	cout << "In order ";
	bst.inorder();
	int max = bst.max();
	cout << "max = " << max << endl;


	return 0;
}