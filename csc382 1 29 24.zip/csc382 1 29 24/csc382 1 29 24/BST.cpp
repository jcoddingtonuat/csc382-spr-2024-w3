
//


#include "BST.h"
#include <iostream>
using namespace std;
BST::BST() //default constructor
{
	root = NULL;
}
bool BST::add(int i)
{
	TreeNode* n = new TreeNode();
	n->item = i;
	if (root == NULL)
	{
		root = n;
		return true;
	}
	else
	{
		TreeNode* p = root;
		while (p != NULL)
		{
			if (i == p->item) //duplicate
				return false;
			else if (i < p->item) //if value to be inserted is less than current nodes value
			{
				if (p->Lchild == NULL) //go to left subtree
				{
					p->Lchild = n;
					return true;
				}
				else
					p = p->Lchild;
			}
			else
			{
				if (p->Rchild == NULL) //go to right subtree
				{
					p->Rchild = n;
					return true;
				}
				else
					p = p->Rchild;
			}
		}
	}
	return false;
}

void BST::inorder(TreeNode* n)
{
	if (n == NULL)
		return;

	inorder(n->Lchild);
	cout << n->item << " ";
	inorder(n->Rchild);

}
void BST::inorder()
{
	inorder(root);
	cout << endl;
}

int BST::max()
{
	if (root == NULL)
		return 0;
	else
	{
		TreeNode* p = root;
		while (p->Rchild != NULL)
			p = p->Rchild;
		return p->item;
	}
}
